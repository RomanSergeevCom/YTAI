# 020101_transcribe v3.0 — Спецификация

## Обзор

Транскрипция v3.0 на базе v2.16: word-level timestamps, Premiere Transcript JSON, глобальная диаризация.
Генерация ingest JSON для UXP-плагина Premiere (020201_premiere_ingest).

**Скрипт:** ~/YTAI/scripts/02_transcribe/020101_transcribe/transcribe_project.py
**Версия:** 3.0
**Зависимости:** whisper, pyannote.audio, torch, ffmpeg, openpyxl, soundfile, numpy

---

## Изменения от v2.16

1. **Пути вывода:** JSON и SRT теперь внутри `_transcription/`. Рядом с видео — ТОЛЬКО xlsx.
2. **Stage 5b (prproj) удалён.** Premiere проект создаётся через UXP-плагин (020201_premiere_ingest).
3. **Stage 6 (новый):** генерация ingest JSON (`{project}_ingest.json`) для UXP-плагина.
4. **Флаг `--multicam`:** мультикамера без мастер-файлов (заменяет `--no-prproj`).

---

## Окружение

    source ~/YTAI/environment/.venv_transcribe/bin/activate

    # Flat проект
    python ~/YTAI/scripts/02_transcribe/020101_transcribe/transcribe_project.py \
      --project "/path/to/Interview" -n 2 -y

    # Мультикамера (без мастер-файлов)
    python ~/YTAI/scripts/02_transcribe/020101_transcribe/transcribe_project.py \
      --project "/path/to/MultiCam" -n 2 --multicam -y

    # Мульти-папки (с мастер-файлами, по умолчанию)
    python ~/YTAI/scripts/02_transcribe/020101_transcribe/transcribe_project.py \
      --project "/path/to/YTCG_Project" -n 2 -y

    # Только перегенерация ingest JSON
    python ~/YTAI/scripts/02_transcribe/020101_transcribe/transcribe_project.py \
      --project "/path/to/Interview" --stages 6

    # Dry-run
    python ~/YTAI/scripts/02_transcribe/020101_transcribe/transcribe_project.py \
      --project "/path/to/Interview" --dry-run

**Python venv:** `~/YTAI/environment/.venv_transcribe`
**HuggingFace token:** автоматически из `~/.huggingface/token` или `~/.cache/huggingface/token`
**Whisper модель:** large-v3 (по умолчанию)
**Устройство:** Apple Silicon MPS (авто-определение)

---

## Параметры запуска

    --project PATH      папка или файл (обязательный)
    -n NUM              количество спикеров (опциональный, auto-detect если не указан)
    -m MODEL            модель Whisper (default: large-v3)
    -y                  пропустить подтверждения
    --language LANG     язык (default: auto-detect)
    --resume            продолжить с последнего этапа
    --stages 3,4,5      только указанные этапы (допустимые: 1, 2, 3, 4, 5, 6)
    --multicam          мультикамера без мастер-файлов
    --dry-run           показать план без запуска

---

## Структура папок

### Вариант A: Flat проект

    Interview/
    +-- *.MP4 (видеофайлы)
    +-- Interview_transcript.xlsx              <- ЕДИНСТВЕННЫЙ файл рядом с видео
    +-- Interview_transcription/
        +-- Interview_transcript.json          <- перенесён из корня (v2.16: был рядом)
        +-- Interview_transcript.srt           <- перенесён из корня (v2.16: был рядом)
        +-- Interview_ingest.json              <- НОВЫЙ (stage 6)
        +-- full_audio.wav
        +-- clip_offsets.json
        +-- diarization.json
        +-- speakers.json
        +-- combined_transcript.json
        +-- meta.json
        +-- *_transcribe_*.log
        +-- per_clip/
            +-- C5090/
                +-- C5090_audio.wav
                +-- C5090_whisper_raw.json
                +-- C5090_transcript.json
                +-- C5090_transcript.srt
                +-- C5090_transcript.txt
                +-- C5090_premiere_transcript.json

### Вариант B: Один файл

    SomeFolder/
    +-- C5090.MP4
    +-- C5090_transcript.xlsx                  <- ЕДИНСТВЕННЫЙ файл рядом
    +-- C5090_transcription/
        +-- C5090_transcript.json
        +-- C5090_transcript.srt
        +-- C5090_ingest.json
        +-- ...

### Вариант C: Подпапки с `--multicam` (мультикамера)

Камеры снимают одно и то же. Мастер-файлы НЕ нужны — контент дублируется.

    YTCG Gambling Ru/
    +-- FX3/                                        <- камера 1
    |   +-- RYA-FX3-0090.MP4, ...
    |   +-- FX3_transcript.xlsx
    |   +-- FX3_transcription/
    |       +-- FX3_transcript.json
    |       +-- FX3_transcript.srt
    |       +-- FX3_ingest.json                     <- per-camera ingest
    |       +-- per_clip/
    |           +-- RYA-FX3-0090/
    |               +-- RYA-FX3-0090_audio.wav
    |               +-- RYA-FX3-0090_transcript.json
    |               +-- RYA-FX3-0090_transcript.srt
    |               +-- RYA-FX3-0090_transcript.txt
    |               +-- RYA-FX3-0090_premiere_transcript.json
    +-- ZVE1/                                       <- камера 2
    |   +-- RYA-ZVE1-1674.MP4, ...
    |   +-- ZVE1_transcript.xlsx
    |   +-- ZVE1_transcription/
    |       +-- ZVE1_transcript.json
    |       +-- ZVE1_transcript.srt
    |       +-- ZVE1_ingest.json
    |       +-- per_clip/...
    +-- YTCG Gambling Ru_transcription/             <- служебная (НЕТ мастер xlsx/json/srt/ingest)
        +-- full_audio.wav
        +-- clip_offsets.json
        +-- diarization.json
        +-- speakers.json
        +-- meta.json
        +-- *.log

### Вариант D: Подпапки без `--multicam` (мульти-папки, по умолчанию)

Папки — разные части проекта. Мастер-файлы НУЖНЫ.

    YTCG Gambling Ru/
    +-- Part1/
    |   +-- *.MP4
    |   +-- Part1_transcript.xlsx
    |   +-- Part1_transcription/
    |       +-- Part1_transcript.json
    |       +-- Part1_transcript.srt
    |       +-- per_clip/...
    +-- Part2/
    |   +-- *.MP4
    |   +-- Part2_transcript.xlsx
    |   +-- Part2_transcription/...
    +-- YTCG Gambling Ru_transcript.xlsx            <- МАСТЕР xlsx (combined)
    +-- YTCG Gambling Ru_transcription/
        +-- YTCG Gambling Ru_transcript.json        <- мастер JSON
        +-- YTCG Gambling Ru_transcript.srt         <- мастер SRT
        +-- YTCG Gambling Ru_ingest.json            <- мастер ingest (для UXP)
        +-- full_audio.wav
        +-- clip_offsets.json
        +-- diarization.json
        +-- speakers.json
        +-- combined_transcript.json
        +-- meta.json
        +-- *.log

### Разница `--multicam` vs по умолчанию

| | `--multicam` | По умолчанию (мульти-папки) |
|---|---|---|
| Мастер xlsx | Нет | Да, в корне |
| Мастер JSON/SRT | Нет | Да, в `_transcription/` |
| Мастер ingest | Нет | Да, в `_transcription/` |
| Per-folder xlsx | Да | Да |
| Per-folder JSON/SRT | Да | Да |
| Per-folder ingest | Да (per-camera) | Нет (только мастер) |
| Общая диаризация | Да | Да |

### Рекурсивный паттерн (каждый уровень)

    {папка}/
    +-- видеофайлы
    +-- {имя_папки}_transcript.xlsx      <- единственный файл рядом
    +-- {имя_папки}_transcription/
        +-- {имя_папки}_transcript.json
        +-- {имя_папки}_transcript.srt
        +-- {имя_папки}_ingest.json
        +-- per_clip/...

---

## Pipeline

    Stage 1: Extract Audio
      Per clip -> WAV (16kHz mono) + concatenate -> full_audio.wav + clip_offsets.json

    Stage 2: Global Diarization
      pyannote on full_audio.wav -> speaker intervals [start, end, SPEAKER_XX]

    Stage 3: Per-clip Whisper
      word_timestamps=True per clip -> words with local timecodes

    Stage 4: Speaker Mapping
      Local word -> global timecode -> speaker via diarization

    Stage 5: Generate Outputs
      xlsx, SRT, TXT, internal JSON, Premiere JSON, transcript.json, meta.json
      JSON и SRT -> внутрь _transcription/ (отличие от v2.16)
      Multi-camera: per-camera XLSX + transcript.json

    Stage 6: Generate Ingest JSON (НОВЫЙ)
      ingest_json.generate() -> {transcription_dir}/{project}_ingest.json

Stage 5b (prproj) из v2.16 удалён. Premiere проект через UXP плагин (020201_premiere_ingest).

---

## Ingest JSON контракт

Файл: `{transcription_dir}/{project}_ingest.json`

```json
{
    "version": "1.0",
    "type": "ingest",
    "project_name": "Interview",
    "created_at": "2026-03-08T12:00:00Z",
    "media": {
        "width": 3840,
        "height": 2160,
        "fps": 25.0,
        "sample_rate": 48000
    },
    "clips": [
        {
            "clip_id": "C5402",
            "filename": "C5402.MP4",
            "path": "/abs/Interview/C5402.MP4",
            "duration": 156.0,
            "offset": 0.0,
            "premiere_transcript": "/abs/Interview_transcription/per_clip/C5402/C5402_premiere_transcript.json"
        }
    ],
    "files": {
        "transcript_json": "/abs/Interview_transcription/Interview_transcript.json",
        "transcript_srt": "/abs/Interview_transcription/Interview_transcript.srt",
        "transcript_xlsx": "/abs/Interview_transcript.xlsx"
    },
    "source_folder": "/abs/Interview"
}
```

Поля:
- `media` — resolution, FPS, sample_rate из первого клипа
- `clips[]` — абсолютные пути к видео и premiere transcript JSON
- `clips[].offset` — смещение клипа в склеенном аудио (для диаризации)
- `files` — абсолютные пути к combined transcript JSON, SRT, XLSX
- `source_folder` — корневая папка проекта

---

## Модуль ingest_json.py

Файл: `~/YTAI/scripts/02_transcribe/020101_transcribe/ingest_json.py`

```python
from ingest_json import generate
ingest_path = generate(Path("/path/to/Interview_transcription/Interview_transcript.json"))
```

Читает `{project}_transcript.json` (внутри `_transcription/`), генерирует `{project}_ingest.json` рядом.

Можно запустить standalone:

    python ingest_json.py /path/to/Interview_transcription/Interview_transcript.json

---

## Структура проекта

    ~/YTAI/scripts/02_transcribe/020101_transcribe/
    +-- transcribe_project.py              # Модифицированная копия v2.16
    +-- ingest_json.py                     # Модуль: генерация ingest JSON
    +-- 020101_transcribe_spec.md          # Эта спецификация
